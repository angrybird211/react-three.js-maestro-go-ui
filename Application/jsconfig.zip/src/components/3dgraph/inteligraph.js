import React, { useState, useEffect} from 'react';
import MetaTags from 'react-meta-tags';
import * as faIcon from 'react-icons/fa';

import {
    Button,
    Fade,
    Offcanvas,
    setShow,
    OffcanvasHeader,
    OffcanvasTitle,
    OffcanvasBody,
    Collapse,
    Card
} from "reactstrap";

function intelBar() {  
    return (
      <div className="intelBar">
         {/* <faIcon.FaBars /> */}




      </div>

    );
  }
  
export default intelBar